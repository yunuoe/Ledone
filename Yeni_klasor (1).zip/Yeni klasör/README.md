**[ABONE OL](https://www.youtube.com/channel/UCkCb5aCRW_3mEzpcPP18iVw?sub_confirmation=1)URMUSUN LÜTFEEEEN**

**[DİSCORD SUNUCUMUZ](https://discord.gg/FAchvKXF9r)**